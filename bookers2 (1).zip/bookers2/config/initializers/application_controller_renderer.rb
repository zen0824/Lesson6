# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9ead0835ee35dbb6eae742f4fe1954b23fad4717355206e27339efa399cbe6af90da21784c68381ef3281e25bc2bc3adc6ba2b4c587270dcf6a20927f51fd460'